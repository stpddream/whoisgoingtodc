S_LANGUAGE Polski
S_LANGUAGE_WORD Język
S_CHANGE_LANGUAGE Zmień język
S_CHOOSE_LANGUAGE Wybierz język
S_LANGUAGE_KEEP_ASKING Pokazuj to okno podczas uruchamiania
S_UNABLE_TO_START_LAUNCHER Nie można uruchomić programu uruchamiającego Opera Mobile Emulator.
S_UNABLE_TO_READ_CONFIG Nie można odczytać pliku konfiguracyjnego Launcher.ini.
S_PROFILE Profil
S_ADD Dodaj
S_REMOVE Usuń
S_WINDOW_SCALE Skalowanie okna
S_ARGUMENTS Argumenty
S_FULL_BROWSER_RESET Przywróć ustawienia domyślne przed uruchomieniem.
S_HELP Pomoc
S_LAUNCH Uruchom
S_ADD_PROFILE Utwórz profil
S_ENTER_PROFILE_NAME Wpisz nazwę nowego profilu.
S_SAVE_SAVE_AS Zapisz/Zapisz jako
S_ENTER_NEW_PROFILE_NAME Wpisz nową nazwę profilu lub pozostaw bieżącą.
S_SAVE_CHANGES Zapisać zmiany?
S_PROFILE_ALREADY_EXISTS Profil %1 już istnieje. Czy chcesz go zastąpić?
S_OK OK
S_CANCEL Anuluj
S_YES Tak
S_NO Nie
S_REMOVE_PROFILE_QUESTION Czy na pewno chcesz usunąć ten profil?
S_CONFIRM_REMOVE_PROFILE Usuń profil
S_NAME Nazwa
S_WIDTH Szerokość
S_HEIGHT Wysokość
S_ADD_RESOLUTION Dodaj rozdzielczość
S_RESOLUTION_TOO_BIG Za duża rozdzielczość
S_RESOLUTION_SIZE_QUESTION Dodajesz rozdzielczość %1x%2, która jest większa od bieżącej rozdzielczości ekranu: %3x%4.\n Czy na pewno kontynuować?
S_PIXEL_DENSITY Gęstość pikseli
S_ADD_PIXEL_DENSITY Dodaj gęstość pikseli
S_FAILED_TO_RESET_BROWSER Przywracanie ustawień domyślnych nie powiodło się – nie można usunąć %1.
S_FAILED_START_EMULATOR Nie można uruchomić Opera Mobile Emulator
S_EMULATOR_WARNING Ostrzeżenie
S_CONFIG_OUT_OF_DATE_REPLACE Plik konfiguracyjny Launcher.ini jest nieaktualny i nie zostanie użyty. Jego nazwa została zmieniona na %1, aby zrobić miejsce dla nowego pliku konfiguracyjnego.
S_CONFIG_OUT_OF_DATE_INFO Plik konfiguracyjny Launcher.ini jest nieaktualny.
S_DEFAULT Domyślna
S_OPTION_STILL_USED_BY_PROFILES Ta opcja jest używana w poniższych profilach. Czy na pewno chcesz kontynuować?
S_CONFIRM_REMOVE Usuń
S_WINDOW_SIZE_WILL_BE_LIMITED Rozmiar okna zostanie ograniczony przez dostępną rozdzielczość ekranu.
S_RESOLUTION Rozdzielczość
S_INPUT Interfejs użytkownika
S_USER_AGENT_STRING User Agent
S_WINDOW_SCALE_TOO_LOW Wybrany rozmiar okna jest mniejszy niż dopuszczalny.
S_SELECT_HIGHER_SCALE Wybierz poziom skali wyższy niż %1.
